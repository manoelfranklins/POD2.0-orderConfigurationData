# Order Configuration Data - POD 2.0 Widget

A custom POD 2.0 widget that displays custom configuration data (`customValues`) from orders in SAP Digital Manufacturing.

## Overview

This widget calls the `/order/v1/orders` API endpoint using the selected order and plant, extracts the `customValues` section from the response, and displays it in a user-friendly table with filtering, sorting, and Excel export capabilities.

## Features

- **Automatic Data Loading**: Loads order data when an order is selected in the POD
- **Search/Filter**: Live search across attribute names and values
- **Column Sorting**: Click column headers to sort ascending/descending
- **Excel Export**: Export table data to CSV file for Excel
- **Refresh Button**: Manually refresh data
- **Configurable Properties**: Control visibility, export button, and logging

## Installation

### 1. Create the Extension Package

Create a ZIP file containing:
```
extension.json
widget/
    OrderConfigurationData.js
```

### 2. Upload to SAP Digital Manufacturing

1. Navigate to **Manage PODs 2.0** app
2. Go to **Extensions** tab
3. Click **Create**
4. Fill in:
   - **Name**: OrderConfigurationData (or your preferred name)
   - **Namespace**: `custom/orderconfigdata`
   - **Source Code**: Upload the ZIP file
5. Click **Create**

### 3. Add Widget to POD

1. Open your POD in Design Mode
2. Find **"Order Configuration Data"** in the plugin palette under **Custom Widgets** category
3. Drag and drop it onto your POD layout
4. Save the POD

## Configuration

| Property | Default | Description |
|----------|---------|-------------|
| **Visible** | true | Show or hide the widget panel |
| **Auto Refresh** | true | Automatically load data when order selection changes |
| **Show Export Button** | true | Show the Excel export button |
| **Log to Console** | true | Enable console logging for debugging |

## API Endpoint

The widget calls:
```
GET /api/order/v1/orders?plant={plant}&order={orderNumber}
```

And extracts the `customValues` section from the response.

## Data Format

The widget handles multiple `customValues` formats:

### Array of Objects
```json
{
    "customValues": [
        { "attribute": "COLOR", "value": "Red" },
        { "attribute": "SIZE", "value": "Large" }
    ]
}
```

### Object with Key-Value Pairs
```json
{
    "customValues": {
        "COLOR": "Red",
        "SIZE": "Large"
    }
}
```

## Table Features

### Search
Type in the search field to filter rows. Searches both attribute names and values simultaneously.

### Sorting
Click the sort icon on column headers to toggle between ascending and descending order.

### Export
Click the Export button to download the data as a CSV file. The filename includes the order number and current date.

## Technical Details

- **Module Path**: `custom/orderconfigdata/widget/OrderConfigurationData`
- **Type**: `custom.orderconfigdata.widget.OrderConfigurationData`
- **Base Class**: `sap/dm/dme/pod2/widget/Widget`
- **Category**: Custom Widgets

## File Structure

```
├── extension.json                      # Extension configuration
├── README.md                           # This file
└── widget/
    └── OrderConfigurationData.js       # Widget implementation
```

## Dependencies

- SAP Digital Manufacturing POD 2.0
- SAPUI5 libraries (included in DM)
- Access to `/order/v1/orders` API endpoint

## POD Context Integration

The widget subscribes to:
- `/selectedWorkListItems` - Gets order from selected work list item
- `/selectedOrder` - Alternative path for order selection

It uses `PodContext.getPlant()` to get the current plant for API calls.

## Debugging

Enable "Log to Console" property to see detailed logs:
- `[OrderConfigData] Loading order data for: ...`
- `[OrderConfigData] Calling API: ...`
- `[OrderConfigData] API response: ...`
- `[OrderConfigData] Custom values extracted: X`

Check browser console (F12) for these messages.

## Notes

- The widget requires an order to be selected to display data
- The panel header updates to show the current order number
- CSV export includes UTF-8 BOM for proper Excel encoding
- Values containing commas or quotes are properly escaped in CSV export

## Version

1.0.0

## License

This extension is provided as-is for SAP Digital Manufacturing customization.